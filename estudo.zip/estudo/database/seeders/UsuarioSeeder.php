<?php

namespace Database\Seeders;

use App\Models\Usuario;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Usuario::factory()
            ->count(20)
            ->hasInvoices(10)
            ->create();

        Usuario::factory()
            ->count(100)
            ->hasInvoices(5)
            ->create();

        Usuario::factory()
            ->count(100)
            ->hasInvoices(3)
            ->create();

        Usuario::factory()
            ->count(5)
            ->create();
    }
}
